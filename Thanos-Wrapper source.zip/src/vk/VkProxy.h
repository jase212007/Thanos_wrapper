#pragma once

namespace thanosray::vk {

void Initialize();
void Shutdown();

} // namespace thanosray::vk
