#pragma once

namespace thanosray::vk {

void InstallHooks();

} // namespace thanosray::vk
