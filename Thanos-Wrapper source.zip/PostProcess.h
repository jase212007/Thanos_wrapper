#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <vulkan/vulkan.h>
#include <cstdint>

namespace thanosray {
    namespace vk {

        struct PostFxConfig
        {
            bool  enable = false;
            float exposureBoost = 0.20f; // 0..1-ish
            float shadowLift = 0.08f; // 0..0.25-ish
            float gamma = 1.05f; // 1.0 = none
            bool  safeModeWaitIdle = true; // safest: waits on queue when recycling semaphores
        };

        class PostProcess
        {
        public:
            static PostProcess& Get();

            // called once we have a working vkGetDeviceProcAddr and a device created
            void OnDeviceCreated(VkPhysicalDevice phys, VkDevice dev, PFN_vkGetDeviceProcAddr gdpa);

            // intercepted swapchain functions
            VkResult CreateSwapchainKHR(
                VkDevice device,
                const VkSwapchainCreateInfoKHR* pCreateInfo,
                const VkAllocationCallbacks* pAllocator,
                VkSwapchainKHR* pSwapchain,
                PFN_vkCreateSwapchainKHR realCreate);

            VkResult GetSwapchainImagesKHR(
                VkDevice device,
                VkSwapchainKHR swapchain,
                uint32_t* pCount,
                VkImage* pImages,
                PFN_vkGetSwapchainImagesKHR realGet);

            VkResult QueuePresentKHR(
                VkQueue queue,
                const VkPresentInfoKHR* pPresentInfo,
                PFN_vkQueuePresentKHR realPresent);

            void OnGetDeviceQueue(VkDevice device, uint32_t queueFamilyIndex, uint32_t queueIndex, VkQueue queue);

        private:
            PostProcess() = default;
            PostProcess(const PostProcess&) = delete;
            PostProcess& operator=(const PostProcess&) = delete;

            // internal helpers
            void LoadConfig();
            bool LoadShaderSpv();
            void Disable(const char* reason);

            bool EnsurePipeline(VkDevice device);
            bool EnsurePerSwapchain(VkDevice device, VkSwapchainKHR sc, VkFormat fmt, VkExtent2D extent);

            bool RecordAndSubmitForImage(VkQueue queue, VkDevice device, VkImage img, VkExtent2D extent);

        private:
            // config
            PostFxConfig cfg_;
            bool cfgLoaded_ = false;

            // vulkan function pointers (device-level)
            PFN_vkCreateSemaphore         vkCreateSemaphore_ = nullptr;
            PFN_vkDestroySemaphore        vkDestroySemaphore_ = nullptr;
            PFN_vkCreateFence             vkCreateFence_ = nullptr;
            PFN_vkDestroyFence            vkDestroyFence_ = nullptr;
            PFN_vkWaitForFences           vkWaitForFences_ = nullptr;
            PFN_vkResetFences             vkResetFences_ = nullptr;
            PFN_vkQueueSubmit             vkQueueSubmit_ = nullptr;

            PFN_vkCreateCommandPool       vkCreateCommandPool_ = nullptr;
            PFN_vkDestroyCommandPool      vkDestroyCommandPool_ = nullptr;
            PFN_vkAllocateCommandBuffers  vkAllocateCommandBuffers_ = nullptr;
            PFN_vkResetCommandPool        vkResetCommandPool_ = nullptr;
            PFN_vkBeginCommandBuffer      vkBeginCommandBuffer_ = nullptr;
            PFN_vkEndCommandBuffer        vkEndCommandBuffer_ = nullptr;
            PFN_vkCmdPipelineBarrier      vkCmdPipelineBarrier_ = nullptr;
            PFN_vkCmdBindPipeline         vkCmdBindPipeline_ = nullptr;
            PFN_vkCmdBindDescriptorSets   vkCmdBindDescriptorSets_ = nullptr;
            PFN_vkCmdPushConstants        vkCmdPushConstants_ = nullptr;
            PFN_vkCmdDispatch             vkCmdDispatch_ = nullptr;

            PFN_vkCreateShaderModule      vkCreateShaderModule_ = nullptr;
            PFN_vkDestroyShaderModule     vkDestroyShaderModule_ = nullptr;
            PFN_vkCreateDescriptorSetLayout vkCreateDescriptorSetLayout_ = nullptr;
            PFN_vkDestroyDescriptorSetLayout vkDestroyDescriptorSetLayout_ = nullptr;
            PFN_vkCreatePipelineLayout    vkCreatePipelineLayout_ = nullptr;
            PFN_vkDestroyPipelineLayout   vkDestroyPipelineLayout_ = nullptr;
            PFN_vkCreateDescriptorPool    vkCreateDescriptorPool_ = nullptr;
            PFN_vkDestroyDescriptorPool   vkDestroyDescriptorPool_ = nullptr;
            PFN_vkAllocateDescriptorSets  vkAllocateDescriptorSets_ = nullptr;
            PFN_vkUpdateDescriptorSets    vkUpdateDescriptorSets_ = nullptr;
            PFN_vkCreateComputePipelines  vkCreateComputePipelines_ = nullptr;
            PFN_vkDestroyPipeline         vkDestroyPipeline_ = nullptr;

            // state
            bool disabled_ = false;

            VkPhysicalDevice phys_ = VK_NULL_HANDLE;
            VkDevice device_ = VK_NULL_HANDLE;

            // queue mapping (from vkGetDeviceQueue hook)
            struct QueueInfo { VkDevice dev; uint32_t family; uint32_t index; };
            // we�ll keep it simple: only one queue is needed (the present queue)
            bool haveQueueInfo_ = false;
            QueueInfo presentQueueInfo_{};

            // swapchain state
            VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
            VkFormat swapchainFmt_ = VK_FORMAT_UNDEFINED;
            VkExtent2D swapchainExtent_{};
            uint32_t swapchainImageCount_ = 0;
            VkImage* swapchainImages_ = nullptr; // owned by us (malloc/free style)
            uint32_t currentImageIndex_ = 0;

            // postfx resources
            VkShaderModule shader_ = VK_NULL_HANDLE;
            VkDescriptorSetLayout dsl_ = VK_NULL_HANDLE;
            VkPipelineLayout pl_ = VK_NULL_HANDLE;
            VkPipeline pipe_ = VK_NULL_HANDLE;
            VkDescriptorPool dp_ = VK_NULL_HANDLE;
            VkDescriptorSet* dsets_ = nullptr; // per swapchain image

            VkCommandPool cmdPool_ = VK_NULL_HANDLE;
            VkCommandBuffer* cmdbufs_ = nullptr; // per swapchain image

            // semaphores per frame (recycled ring)
            static const uint32_t kSemRing = 8;
            VkSemaphore semRing_[kSemRing]{};
            VkFence     fenceRing_[kSemRing]{};
            uint32_t    semRingCursor_ = 0;
        };

    } // namespace vk
} // namespace thanosray

