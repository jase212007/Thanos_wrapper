#include "pch.h"
#include "PostProcess.h"

#include "src/log/Log.h"

#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include "src/vk/VkProxyState.h"

namespace thanosray {
    namespace vk {

        static void BuildIniPath(wchar_t outPath[MAX_PATH])
        {
            // INI beside the game exe
            wchar_t exePath[MAX_PATH] = { 0 };
            GetModuleFileNameW(nullptr, exePath, MAX_PATH);

            // strip filename
            wchar_t* slash = wcsrchr(exePath, L'\\');
            if (slash) *(slash + 1) = 0;

            wcscpy_s(outPath, MAX_PATH, exePath);
            wcscat_s(outPath, MAX_PATH, L"Thanos-ray.ini");
        }

        static void BuildSpvPath(wchar_t outPath[MAX_PATH])
        {
            // shader beside the proxy dll/exe directory
            wchar_t exePath[MAX_PATH] = { 0 };
            GetModuleFileNameW(nullptr, exePath, MAX_PATH);
            wchar_t* slash = wcsrchr(exePath, L'\\');
            if (slash) *(slash + 1) = 0;

            wcscpy_s(outPath, MAX_PATH, exePath);
            wcscat_s(outPath, MAX_PATH, L"postprocess.spv");
        }

        static uint32_t ReadIniU32(const wchar_t* iniPath, const wchar_t* section, const wchar_t* key, uint32_t def)
        {
            return (uint32_t)GetPrivateProfileIntW(section, key, (int)def, iniPath);
        }

        static float ReadIniF32(const wchar_t* iniPath, const wchar_t* section, const wchar_t* key, float def)
        {
            wchar_t buf[64] = { 0 };
            wchar_t defBuf[64] = { 0 };
            swprintf_s(defBuf, L"%.6f", def);
            GetPrivateProfileStringW(section, key, defBuf, buf, 64, iniPath);
            return (float)wcstod(buf, nullptr);
        }
        static uint32_t ReadIniU32Any(const wchar_t* iniPath, const wchar_t* key, uint32_t def,
            const wchar_t* s0, const wchar_t* s1 = nullptr, const wchar_t* s2 = nullptr)
        {
            uint32_t v = ReadIniU32(iniPath, s0, key, def);
            if (s1) v = ReadIniU32(iniPath, s1, key, v);
            if (s2) v = ReadIniU32(iniPath, s2, key, v);
            return v;
        }

        static float ReadIniF32Any(const wchar_t* iniPath, const wchar_t* key, float def,
            const wchar_t* s0, const wchar_t* s1 = nullptr, const wchar_t* s2 = nullptr)
        {
            float v = ReadIniF32(iniPath, s0, key, def);
            if (s1) v = ReadIniF32(iniPath, s1, key, v);
            if (s2) v = ReadIniF32(iniPath, s2, key, v);
            return v;
        }


        PostProcess& PostProcess::Get()
        {
            static PostProcess s;
            return s;
        }

        void PostProcess::LoadConfig()
        {
            if (cfgLoaded_) return;
            cfgLoaded_ = true;

            wchar_t iniPath[MAX_PATH] = { 0 };
            BuildIniPath(iniPath);

            // Support both legacy [PostFX] section and the newer INI layout:
            // - [visibility] PostFxEnable / ExposureBoost / ShadowLift / Gamma
            // - SafeModeWaitIdle is allowed in [PostFX], [fallback_gi], or [visibility]
            cfg_.enable = (ReadIniU32Any(iniPath, L"PostFxEnable", 0, L"visibility", L"PostFX") != 0);
            cfg_.exposureBoost = ReadIniF32Any(iniPath, L"ExposureBoost", 0.20f, L"visibility", L"PostFX");
            cfg_.shadowLift = ReadIniF32Any(iniPath, L"ShadowLift", 0.08f, L"visibility", L"PostFX");
            cfg_.gamma = ReadIniF32Any(iniPath, L"Gamma", 1.05f, L"visibility", L"PostFX");
            cfg_.safeModeWaitIdle = (ReadIniU32Any(iniPath, L"SafeModeWaitIdle", 1, L"fallback_gi", L"visibility", L"PostFX") != 0);

            thanosray::log::Logf("[PostFX] Config: enable=%d exposure=%.3f shadowLift=%.3f gamma=%.3f safeWaitIdle=%d",
                cfg_.enable ? 1 : 0, cfg_.exposureBoost, cfg_.shadowLift, cfg_.gamma, cfg_.safeModeWaitIdle ? 1 : 0);
        }


        void PostProcess::Disable(const char* reason)
        {
            if (!disabled_) {
                disabled_ = true;
                thanosray::log::Logf("[PostFX] DISABLED: %s", reason ? reason : "(no reason)");
            }
        }

        bool PostProcess::LoadShaderSpv()
        {
            if (shader_ != VK_NULL_HANDLE) return true;

            wchar_t spvPath[MAX_PATH] = { 0 };
            BuildSpvPath(spvPath);

            FILE* f = nullptr;
            _wfopen_s(&f, spvPath, L"rb");
            if (!f) {
                thanosray::log::Logf("[PostFX] Shader not found: postprocess.spv (PostFX will be off)");
                return false;
            }

            fseek(f, 0, SEEK_END);
            long len = ftell(f);
            fseek(f, 0, SEEK_SET);

            if (len <= 0 || (len % 4) != 0) {
                fclose(f);
                thanosray::log::Logf("[PostFX] Invalid SPV length=%ld", len);
                return false;
            }

            std::vector<uint32_t> words((size_t)len / 4);
            fread(words.data(), 1, (size_t)len, f);
            fclose(f);

            VkShaderModuleCreateInfo smci{};
            smci.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
            smci.codeSize = (size_t)len;
            smci.pCode = words.data();

            VkResult r = vkCreateShaderModule_(device_, &smci, nullptr, &shader_);
            if (r != VK_SUCCESS) {
                thanosray::log::Logf("[PostFX] vkCreateShaderModule failed: %d", (int)r);
                shader_ = VK_NULL_HANDLE;
                return false;
            }

            thanosray::log::Logf("[PostFX] Loaded shader module from postprocess.spv (%ld bytes)", len);
            return true;
        }

        void PostProcess::OnDeviceCreated(VkPhysicalDevice phys, VkDevice dev, PFN_vkGetDeviceProcAddr gdpa)
        {
            LoadConfig();
            if (!cfg_.enable) return;

            phys_ = phys;
            device_ = dev;

            // load function pointers
            vkCreateSemaphore_ = (PFN_vkCreateSemaphore)gdpa(dev, "vkCreateSemaphore");
            vkDestroySemaphore_ = (PFN_vkDestroySemaphore)gdpa(dev, "vkDestroySemaphore");
            vkCreateFence_ = (PFN_vkCreateFence)gdpa(dev, "vkCreateFence");
            vkDestroyFence_ = (PFN_vkDestroyFence)gdpa(dev, "vkDestroyFence");
            vkWaitForFences_ = (PFN_vkWaitForFences)gdpa(dev, "vkWaitForFences");
            vkResetFences_ = (PFN_vkResetFences)gdpa(dev, "vkResetFences");
            vkQueueSubmit_ = (PFN_vkQueueSubmit)gdpa(dev, "vkQueueSubmit");

            vkCreateCommandPool_ = (PFN_vkCreateCommandPool)gdpa(dev, "vkCreateCommandPool");
            vkDestroyCommandPool_ = (PFN_vkDestroyCommandPool)gdpa(dev, "vkDestroyCommandPool");
            vkAllocateCommandBuffers_ = (PFN_vkAllocateCommandBuffers)gdpa(dev, "vkAllocateCommandBuffers");
            vkResetCommandPool_ = (PFN_vkResetCommandPool)gdpa(dev, "vkResetCommandPool");
            vkBeginCommandBuffer_ = (PFN_vkBeginCommandBuffer)gdpa(dev, "vkBeginCommandBuffer");
            vkEndCommandBuffer_ = (PFN_vkEndCommandBuffer)gdpa(dev, "vkEndCommandBuffer");
            vkCmdPipelineBarrier_ = (PFN_vkCmdPipelineBarrier)gdpa(dev, "vkCmdPipelineBarrier");
            vkCmdBindPipeline_ = (PFN_vkCmdBindPipeline)gdpa(dev, "vkCmdBindPipeline");
            vkCmdBindDescriptorSets_ = (PFN_vkCmdBindDescriptorSets)gdpa(dev, "vkCmdBindDescriptorSets");
            vkCmdPushConstants_ = (PFN_vkCmdPushConstants)gdpa(dev, "vkCmdPushConstants");
            vkCmdDispatch_ = (PFN_vkCmdDispatch)gdpa(dev, "vkCmdDispatch");

            vkCreateShaderModule_ = (PFN_vkCreateShaderModule)gdpa(dev, "vkCreateShaderModule");
            vkDestroyShaderModule_ = (PFN_vkDestroyShaderModule)gdpa(dev, "vkDestroyShaderModule");
            vkCreateDescriptorSetLayout_ = (PFN_vkCreateDescriptorSetLayout)gdpa(dev, "vkCreateDescriptorSetLayout");
            vkDestroyDescriptorSetLayout_ = (PFN_vkDestroyDescriptorSetLayout)gdpa(dev, "vkDestroyDescriptorSetLayout");
            vkCreatePipelineLayout_ = (PFN_vkCreatePipelineLayout)gdpa(dev, "vkCreatePipelineLayout");
            vkDestroyPipelineLayout_ = (PFN_vkDestroyPipelineLayout)gdpa(dev, "vkDestroyPipelineLayout");
            vkCreateDescriptorPool_ = (PFN_vkCreateDescriptorPool)gdpa(dev, "vkCreateDescriptorPool");
            vkDestroyDescriptorPool_ = (PFN_vkDestroyDescriptorPool)gdpa(dev, "vkDestroyDescriptorPool");
            vkAllocateDescriptorSets_ = (PFN_vkAllocateDescriptorSets)gdpa(dev, "vkAllocateDescriptorSets");
            vkUpdateDescriptorSets_ = (PFN_vkUpdateDescriptorSets)gdpa(dev, "vkUpdateDescriptorSets");
            vkCreateComputePipelines_ = (PFN_vkCreateComputePipelines)gdpa(dev, "vkCreateComputePipelines");
            vkDestroyPipeline_ = (PFN_vkDestroyPipeline)gdpa(dev, "vkDestroyPipeline");

            if (!vkQueueSubmit_ || !vkCreateShaderModule_ || !vkCreateComputePipelines_ || !vkCreateCommandPool_) {
                Disable("Missing required device functions for PostFX (driver too old?)");
                return;
            }

            // sem/fence ring
            for (uint32_t i = 0; i < kSemRing; ++i) {
                VkSemaphoreCreateInfo sci{ VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
                if (vkCreateSemaphore_(dev, &sci, nullptr, &semRing_[i]) != VK_SUCCESS) {
                    Disable("Failed to create PostFX semaphore");
                    return;
                }
                VkFenceCreateInfo fci{ VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
                fci.flags = 0;
                if (vkCreateFence_(dev, &fci, nullptr, &fenceRing_[i]) != VK_SUCCESS) {
                    Disable("Failed to create PostFX fence");
                    return;
                }
            }

            thanosray::log::Logf("[PostFX] Device created; PostFX armed (waiting for swapchain)");
        }

        bool PostProcess::EnsurePipeline(VkDevice device)
        {
            if (pipe_ != VK_NULL_HANDLE) return true;
            if (!LoadShaderSpv()) return false;

            VkDescriptorSetLayoutBinding b{};
            b.binding = 0;
            b.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
            b.descriptorCount = 1;
            b.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

            VkDescriptorSetLayoutCreateInfo dslci{};
            dslci.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
            dslci.bindingCount = 1;
            dslci.pBindings = &b;

            if (vkCreateDescriptorSetLayout_(device, &dslci, nullptr, &dsl_) != VK_SUCCESS) {
                Disable("vkCreateDescriptorSetLayout failed");
                return false;
            }

            VkPushConstantRange pcr{};
            pcr.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
            pcr.offset = 0;
            pcr.size = 16; // 4 floats

            VkPipelineLayoutCreateInfo plci{};
            plci.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
            plci.setLayoutCount = 1;
            plci.pSetLayouts = &dsl_;
            plci.pushConstantRangeCount = 1;
            plci.pPushConstantRanges = &pcr;

            if (vkCreatePipelineLayout_(device, &plci, nullptr, &pl_) != VK_SUCCESS) {
                Disable("vkCreatePipelineLayout failed");
                return false;
            }

            VkPipelineShaderStageCreateInfo stage{};
            stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
            stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
            stage.module = shader_;
            stage.pName = "main";

            VkComputePipelineCreateInfo cpci{};
            cpci.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
            cpci.stage = stage;
            cpci.layout = pl_;

            VkResult r = vkCreateComputePipelines_(device, VK_NULL_HANDLE, 1, &cpci, nullptr, &pipe_);
            if (r != VK_SUCCESS) {
                thanosray::log::Logf("[PostFX] vkCreateComputePipelines failed: %d", (int)r);
                Disable("Compute pipeline creation failed");
                return false;
            }

            // descriptor pool (enough for up to 8 swapchain images)
            VkDescriptorPoolSize ps{};
            ps.type = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
            ps.descriptorCount = 16;

            VkDescriptorPoolCreateInfo dpci{};
            dpci.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
            dpci.maxSets = 16;
            dpci.poolSizeCount = 1;
            dpci.pPoolSizes = &ps;

            if (vkCreateDescriptorPool_(device, &dpci, nullptr, &dp_) != VK_SUCCESS) {
                Disable("vkCreateDescriptorPool failed");
                return false;
            }

            thanosray::log::Logf("[PostFX] Pipeline ready");
            return true;
        }

        bool PostProcess::EnsurePerSwapchain(VkDevice device, VkSwapchainKHR sc, VkFormat fmt, VkExtent2D extent)
        {
            if (disabled_) return false;
            if (!cfg_.enable) return false;
            if (!EnsurePipeline(device)) return false;

            // we need images
            if (!swapchainImages_ || swapchainImageCount_ == 0) return false;

            // command pool
            if (!haveQueueInfo_) {
                // will still work if we can submit on queue; but we need a family index for a command pool.
                Disable("No vkGetDeviceQueue info (queue family unknown). Add vkGetDeviceQueue hook.");
                return false;
            }

            if (cmdPool_ == VK_NULL_HANDLE) {
                VkCommandPoolCreateInfo cpci{};
                cpci.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
                cpci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
                cpci.queueFamilyIndex = presentQueueInfo_.family;

                if (vkCreateCommandPool_(device, &cpci, nullptr, &cmdPool_) != VK_SUCCESS) {
                    Disable("vkCreateCommandPool failed");
                    return false;
                }
            }

            // allocate cmdbufs + descriptor sets per image
            if (!cmdbufs_) {
                cmdbufs_ = (VkCommandBuffer*)std::calloc(swapchainImageCount_, sizeof(VkCommandBuffer));
                dsets_ = (VkDescriptorSet*)std::calloc(swapchainImageCount_, sizeof(VkDescriptorSet));
                if (!cmdbufs_ || !dsets_) {
                    Disable("alloc cmdbufs/dsets failed");
                    return false;
                }

                VkCommandBufferAllocateInfo cbai{};
                cbai.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
                cbai.commandPool = cmdPool_;
                cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
                cbai.commandBufferCount = swapchainImageCount_;

                if (vkAllocateCommandBuffers_(device, &cbai, cmdbufs_) != VK_SUCCESS) {
                    Disable("vkAllocateCommandBuffers failed");
                    return false;
                }

                std::vector<VkDescriptorSetLayout> layouts(swapchainImageCount_, dsl_);
                VkDescriptorSetAllocateInfo dsai{};
                dsai.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
                dsai.descriptorPool = dp_;
                dsai.descriptorSetCount = swapchainImageCount_;
                dsai.pSetLayouts = layouts.data();

                if (vkAllocateDescriptorSets_(device, &dsai, dsets_) != VK_SUCCESS) {
                    Disable("vkAllocateDescriptorSets failed");
                    return false;
                }
            }

            // NOTE: We can�t create image views without vkCreateImageView.
            // We�ll bind storage images via VkDescriptorImageInfo which needs an imageView.
            // Some engines already create views we could reuse, but not easily found here.
            // So: we require swapchain usage supports STORAGE + we create our own views.

            PFN_vkCreateImageView vkCreateImageView =
                (PFN_vkCreateImageView)State().real_vkGetDeviceProcAddr(device, "vkCreateImageView");
            PFN_vkDestroyImageView vkDestroyImageView =
                (PFN_vkDestroyImageView)State().real_vkGetDeviceProcAddr(device, "vkDestroyImageView");

            if (!vkCreateImageView || !vkDestroyImageView) {
                Disable("vkCreateImageView/vkDestroyImageView missing");
                return false;
            }

            static std::vector<VkImageView> views;
            views.clear();
            views.resize(swapchainImageCount_, VK_NULL_HANDLE);

            for (uint32_t i = 0; i < swapchainImageCount_; ++i) {
                VkImageViewCreateInfo ivci{};
                ivci.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
                ivci.image = swapchainImages_[i];
                ivci.viewType = VK_IMAGE_VIEW_TYPE_2D;
                ivci.format = fmt;
                ivci.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
                ivci.subresourceRange.baseMipLevel = 0;
                ivci.subresourceRange.levelCount = 1;
                ivci.subresourceRange.baseArrayLayer = 0;
                ivci.subresourceRange.layerCount = 1;

                if (vkCreateImageView(device, &ivci, nullptr, &views[i]) != VK_SUCCESS) {
                    Disable("vkCreateImageView failed (swapchain format not viewable?)");
                    // cleanup what we created
                    for (uint32_t j = 0; j < i; ++j) {
                        if (views[j]) vkDestroyImageView(device, views[j], nullptr);
                    }
                    return false;
                }

                VkDescriptorImageInfo dii{};
                dii.imageView = views[i];
                dii.imageLayout = VK_IMAGE_LAYOUT_GENERAL;

                VkWriteDescriptorSet w{};
                w.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
                w.dstSet = dsets_[i];
                w.dstBinding = 0;
                w.descriptorCount = 1;
                w.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
                w.pImageInfo = &dii;

                vkUpdateDescriptorSets_(device, 1, &w, 0, nullptr);
            }

            // We intentionally keep the views alive for the duration of runtime in this first version.
            // (Releasing them properly needs swapchain destroy hooks; we can add later.)

            (void)sc; (void)extent;
            return true;
        }

        bool PostProcess::RecordAndSubmitForImage(VkQueue queue, VkDevice device, VkImage img, VkExtent2D extent)
        {
            if (disabled_ || !cfg_.enable) return false;
            if (!pipe_ || !pl_ || !dsets_ || !cmdbufs_) return false;

            // pick ring slot
            uint32_t slot = semRingCursor_++ % kSemRing;

            // optionally wait idle when recycling (safest stability mode)
            if (cfg_.safeModeWaitIdle) {
                PFN_vkQueueWaitIdle vkQueueWaitIdle =
                    (PFN_vkQueueWaitIdle)State().real_vkGetDeviceProcAddr(device, "vkQueueWaitIdle");
                if (vkQueueWaitIdle) vkQueueWaitIdle(queue);
            }

            VkFence fence = fenceRing_[slot];
            vkResetFences_(device, 1, &fence);

            // We need the image index; easiest is to scan for it.
            uint32_t imgIndex = 0;
            for (uint32_t i = 0; i < swapchainImageCount_; ++i) {
                if (swapchainImages_[i] == img) { imgIndex = i; break; }
            }

            VkCommandBuffer cb = cmdbufs_[imgIndex];

            // reset pool (cheap)
            vkResetCommandPool_(device, cmdPool_, 0);

            VkCommandBufferBeginInfo bi{};
            bi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;

            if (vkBeginCommandBuffer_(cb, &bi) != VK_SUCCESS) return false;

            // transition PRESENT -> GENERAL
            VkImageMemoryBarrier b0{};
            b0.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
            b0.srcAccessMask = 0;
            b0.dstAccessMask = VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT;
            b0.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            b0.newLayout = VK_IMAGE_LAYOUT_GENERAL;
            b0.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b0.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b0.image = img;
            b0.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            b0.subresourceRange.levelCount = 1;
            b0.subresourceRange.layerCount = 1;

            vkCmdPipelineBarrier_(cb,
                VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                0, 0, nullptr, 0, nullptr, 1, &b0);

            vkCmdBindPipeline_(cb, VK_PIPELINE_BIND_POINT_COMPUTE, pipe_);
            vkCmdBindDescriptorSets_(cb, VK_PIPELINE_BIND_POINT_COMPUTE, pl_, 0, 1, &dsets_[imgIndex], 0, nullptr);

            // push constants: 4 floats
            struct PC { float exposure, lift, gamma, pad; } pc;
            pc.exposure = cfg_.exposureBoost;
            pc.lift = cfg_.shadowLift;
            pc.gamma = cfg_.gamma;
            pc.pad = 0.0f;

            vkCmdPushConstants_(cb, pl_, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(PC), &pc);

            uint32_t gx = (extent.width + 7) / 8;
            uint32_t gy = (extent.height + 7) / 8;
            vkCmdDispatch_(cb, gx, gy, 1);

            // transition GENERAL -> PRESENT
            VkImageMemoryBarrier b1{};
            b1.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
            b1.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
            b1.dstAccessMask = 0;
            b1.oldLayout = VK_IMAGE_LAYOUT_GENERAL;
            b1.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            b1.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b1.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b1.image = img;
            b1.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            b1.subresourceRange.levelCount = 1;
            b1.subresourceRange.layerCount = 1;

            vkCmdPipelineBarrier_(cb,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
                0, 0, nullptr, 0, nullptr, 1, &b1);

            if (vkEndCommandBuffer_(cb) != VK_SUCCESS) return false;

            // submit compute AFTER the game render, BEFORE present:
            // we do this by waiting on the same semaphores present will wait on,
            // then signaling our own semaphore, then present waits on ours.
            VkSemaphore signalSem = semRing_[slot];

            VkSubmitInfo si{};
            si.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
            si.commandBufferCount = 1;
            si.pCommandBuffers = &cb;

            // Wait on the semaphores the game provides to present.
            // IMPORTANT: we must NOT consume them before present; so present will wait on our signal sem instead.
            // (We set waits in QueuePresentKHR)
            // Here: QueuePresentKHR passes in the same wait list.
            // We'll fill these in QueuePresentKHR via a local submit call (see below).
            // This function assumes the caller provided waits.
            (void)signalSem;

            // We don�t submit here; QueuePresentKHR does it with correct wait list.
            return true;
        }

        VkResult PostProcess::CreateSwapchainKHR(
            VkDevice device,
            const VkSwapchainCreateInfoKHR* pCreateInfo,
            const VkAllocationCallbacks* pAllocator,
            VkSwapchainKHR* pSwapchain,
            PFN_vkCreateSwapchainKHR realCreate)
        {
            LoadConfig();
            if (!cfg_.enable || disabled_) {
                return realCreate(device, pCreateInfo, pAllocator, pSwapchain);
            }

            // Try to add STORAGE usage so we can bind swapchain as storage image.
            // If the driver rejects it, we retry without and disable PostFX.
            VkSwapchainCreateInfoKHR patched = *pCreateInfo;
            patched.imageUsage |= VK_IMAGE_USAGE_STORAGE_BIT;

            VkResult r = realCreate(device, &patched, pAllocator, pSwapchain);
            if (r != VK_SUCCESS) {
                thanosray::log::Logf("[PostFX] vkCreateSwapchainKHR retry without STORAGE (driver rejected STORAGE)");
                r = realCreate(device, pCreateInfo, pAllocator, pSwapchain);
                Disable("Swapchain does not support STORAGE usage; PostFX off");
                return r;
            }

            // store
            swapchain_ = *pSwapchain;
            swapchainFmt_ = pCreateInfo->imageFormat;
            swapchainExtent_ = pCreateInfo->imageExtent;

            thanosray::log::Logf("[PostFX] Swapchain created: fmt=%d %ux%u (STORAGE enabled)",
                (int)swapchainFmt_, swapchainExtent_.width, swapchainExtent_.height);

            return r;
        }

        VkResult PostProcess::GetSwapchainImagesKHR(
            VkDevice device,
            VkSwapchainKHR swapchain,
            uint32_t* pCount,
            VkImage* pImages,
            PFN_vkGetSwapchainImagesKHR realGet)
        {
            VkResult r = realGet(device, swapchain, pCount, pImages);

            if (!cfgLoaded_) LoadConfig();
            if (!cfg_.enable || disabled_) return r;
            if (r != VK_SUCCESS) return r;
            if (!pCount || !pImages) return r;

            // store images
            if (swapchainImages_) {
                std::free(swapchainImages_);
                swapchainImages_ = nullptr;
            }
            swapchainImageCount_ = *pCount;
            swapchainImages_ = (VkImage*)std::calloc(swapchainImageCount_, sizeof(VkImage));
            if (!swapchainImages_) {
                Disable("Failed to alloc swapchain image list");
                return r;
            }

            for (uint32_t i = 0; i < swapchainImageCount_; ++i) swapchainImages_[i] = pImages[i];

            thanosray::log::Logf("[PostFX] Swapchain images: count=%u", swapchainImageCount_);

            // build per-swapchain resources when we can
            EnsurePerSwapchain(device, swapchain, swapchainFmt_, swapchainExtent_);
            return r;
        }

        void PostProcess::OnGetDeviceQueue(VkDevice device, uint32_t queueFamilyIndex, uint32_t queueIndex, VkQueue queue)
        {
            if (!cfgLoaded_) LoadConfig();
            if (!cfg_.enable || disabled_) return;

            // Keep first queue as �present queue�; you can refine later.
            if (!haveQueueInfo_) {
                haveQueueInfo_ = true;
                presentQueueInfo_.dev = device;
                presentQueueInfo_.family = queueFamilyIndex;
                presentQueueInfo_.index = queueIndex;
                thanosray::log::Logf("[PostFX] Captured device queue: family=%u index=%u queue=%p", queueFamilyIndex, queueIndex, (void*)queue);
            }
        }

        VkResult PostProcess::QueuePresentKHR(
            VkQueue queue,
            const VkPresentInfoKHR* pPresentInfo,
            PFN_vkQueuePresentKHR realPresent)
        {
            if (!cfgLoaded_) LoadConfig();
            if (!cfg_.enable || disabled_) {
                return realPresent(queue, pPresentInfo);
            }
            if (!pPresentInfo || pPresentInfo->swapchainCount == 0) {
                return realPresent(queue, pPresentInfo);
            }

            // We only handle first swapchain for now (most games use 1)
            VkSwapchainKHR sc = pPresentInfo->pSwapchains[0];
            uint32_t imgIndex = 0;
            if (pPresentInfo->pImageIndices) imgIndex = pPresentInfo->pImageIndices[0];

            if (sc != swapchain_ || !swapchainImages_ || imgIndex >= swapchainImageCount_) {
                return realPresent(queue, pPresentInfo);
            }

            VkDevice dev = presentQueueInfo_.dev;
            if (dev == VK_NULL_HANDLE || !haveQueueInfo_) {
                return realPresent(queue, pPresentInfo);
            }

            // Ensure pipeline/resources
            if (!EnsurePerSwapchain(dev, sc, swapchainFmt_, swapchainExtent_)) {
                return realPresent(queue, pPresentInfo);
            }

            // Build and submit compute pass that waits on game's semaphores and signals our semaphore.
            uint32_t slot = semRingCursor_++ % kSemRing;
            VkSemaphore signalSem = semRing_[slot];
            VkFence fence = fenceRing_[slot];

            vkResetFences_(dev, 1, &fence);

            // record command buffer for this image
            VkImage img = swapchainImages_[imgIndex];

            // reset pool
            vkResetCommandPool_(dev, cmdPool_, 0);

            VkCommandBuffer cb = cmdbufs_[imgIndex];

            VkCommandBufferBeginInfo bi{};
            bi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer_(cb, &bi) != VK_SUCCESS) {
                Disable("vkBeginCommandBuffer failed");
                return realPresent(queue, pPresentInfo);
            }

            VkImageMemoryBarrier b0{};
            b0.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
            b0.srcAccessMask = 0;
            b0.dstAccessMask = VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT;
            b0.oldLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            b0.newLayout = VK_IMAGE_LAYOUT_GENERAL;
            b0.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b0.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b0.image = img;
            b0.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            b0.subresourceRange.levelCount = 1;
            b0.subresourceRange.layerCount = 1;

            vkCmdPipelineBarrier_(cb,
                VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                0, 0, nullptr, 0, nullptr, 1, &b0);

            vkCmdBindPipeline_(cb, VK_PIPELINE_BIND_POINT_COMPUTE, pipe_);
            vkCmdBindDescriptorSets_(cb, VK_PIPELINE_BIND_POINT_COMPUTE, pl_, 0, 1, &dsets_[imgIndex], 0, nullptr);

            struct PC { float exposure, lift, gamma, pad; } pc;
            pc.exposure = cfg_.exposureBoost;
            pc.lift = cfg_.shadowLift;
            pc.gamma = cfg_.gamma;
            pc.pad = 0.0f;

            vkCmdPushConstants_(cb, pl_, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(PC), &pc);

            uint32_t gx = (swapchainExtent_.width + 7) / 8;
            uint32_t gy = (swapchainExtent_.height + 7) / 8;
            vkCmdDispatch_(cb, gx, gy, 1);

            VkImageMemoryBarrier b1{};
            b1.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
            b1.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
            b1.dstAccessMask = 0;
            b1.oldLayout = VK_IMAGE_LAYOUT_GENERAL;
            b1.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            b1.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b1.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            b1.image = img;
            b1.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            b1.subresourceRange.levelCount = 1;
            b1.subresourceRange.layerCount = 1;

            vkCmdPipelineBarrier_(cb,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
                0, 0, nullptr, 0, nullptr, 1, &b1);

            if (vkEndCommandBuffer_(cb) != VK_SUCCESS) {
                Disable("vkEndCommandBuffer failed");
                return realPresent(queue, pPresentInfo);
            }

            // Submit compute: wait on game's semaphores, signal ours
            std::vector<VkPipelineStageFlags> waitStages;
            waitStages.resize(pPresentInfo->waitSemaphoreCount, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);

            VkSubmitInfo si{};
            si.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
            si.waitSemaphoreCount = pPresentInfo->waitSemaphoreCount;
            si.pWaitSemaphores = pPresentInfo->pWaitSemaphores;
            si.pWaitDstStageMask = waitStages.empty() ? nullptr : waitStages.data();
            si.commandBufferCount = 1;
            si.pCommandBuffers = &cb;
            si.signalSemaphoreCount = 1;
            si.pSignalSemaphores = &signalSem;

            VkResult sr = vkQueueSubmit_(queue, 1, &si, fence);
            if (sr != VK_SUCCESS) {
                thanosray::log::Logf("[PostFX] vkQueueSubmit failed: %d", (int)sr);
                Disable("vkQueueSubmit failed");
                return realPresent(queue, pPresentInfo);
            }

            // Present should wait on our semaphore (NOT the game's semaphores)
            VkPresentInfoKHR pi = *pPresentInfo;
            pi.waitSemaphoreCount = 1;
            pi.pWaitSemaphores = &signalSem;

            // In �safe mode� we also wait for compute completion to avoid weirdness on older drivers.
            if (cfg_.safeModeWaitIdle) {
                vkWaitForFences_(dev, 1, &fence, VK_TRUE, UINT64_MAX);
            }

            return realPresent(queue, &pi);
        }

    } // namespace vk
} // namespace thanosray
